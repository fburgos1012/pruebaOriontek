## PHP CRUD API
* `GET - http://localhost:8080/api/read.php` Fetch ALL Records
* `GET - localhost:8080/api/single_read.php/?id=2` Fetch Single Record
* `POST - http://localhost:8080/api/create.php` Create Record
* `POST - http://localhost:8080/api/update.php` Update Record
* `DELETE - localhost:8080/api/delete.php` Remove Records
